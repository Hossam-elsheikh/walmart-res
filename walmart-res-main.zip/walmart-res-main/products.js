export const products = [
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
  {
    img: "https://i5.walmartimages.com/seo/2022-Apple-MacBook-Air-Laptop-with-M2-chip-13-6-inch-Liquid-Retina-Display-8GB-RAM-256SSD-Storage-Midnight-Certified-Pre-Owned_1112ee91-a199-4643-aa39-230497a0f0a4.a640fb95354fce8e0702e620dcdb5a8b.jpeg?odnHeight=175&odnWidth=175&odnBg=FFFFFF",
    price: "$859.00",
    options: "Options from $879.00 – $1,019.00",
    title:
      "2022 Apple MacBook Air Laptop with M2 chip: 13.6-inch Liquid Retina Display, 8GB RAM, 256SSD Storage, Midnight, Certified Pre-Owned",
  },
];
